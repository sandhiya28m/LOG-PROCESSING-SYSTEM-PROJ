# Email Configuration for Alert System

SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
SENDER_EMAIL = "alertslogprocessingsystem@gmail.com"
SENDER_PASSWORD = "xtrt fbxk zprh kfms"
RECEIVER_EMAILS = ["monkey1d2luffy31@gmail.com"]
